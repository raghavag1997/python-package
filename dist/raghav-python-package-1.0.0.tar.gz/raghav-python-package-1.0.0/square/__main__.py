def main():
    number = int(input('Enter the number'))
    print(f'{number} square is {number**2}')

if __name__ == '__main__':
    main()
        