# raghav sample Package
It takes an integer as an input and prints it sqaure

## Installation
``` pip install raghav-sample-package```

## License

2021 Raghav Agarwal

